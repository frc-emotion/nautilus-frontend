## Overview

This is a Kotlin reference app for the AndroidBeaconLibrary

## Project Setup

1. Install [Android Studio](https://developer.android.com/sdk/installing/studio.html) 4.1+
2. Open this project

See the [Java refernce app here.](https://github.com/AltBeacon/android-beacon-library-reference)
